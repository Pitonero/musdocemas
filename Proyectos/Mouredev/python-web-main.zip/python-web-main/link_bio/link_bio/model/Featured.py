import reflex as rx


class Featured(rx.Base):
    title: str
    image: str
    url: str
