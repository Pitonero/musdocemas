from flask import Flask, jsonify, request
import random

app = Flask(__name__)

# Estado inicial del juego
game_state = {
    "player_cards": [],
    "ai_cards": [],
    "message": "Turno del Jugador"
}

# Función para repartir cartas
def deal_cards():
    return [random.choice(["Oros", "Copas", "Espadas", "Bastos"]) for _ in range(4)]

# Inicialización del juego
@app.route('/start')
def start_game():
    game_state["player_cards"] = deal_cards()
    game_state["ai_cards"] = deal_cards()
    game_state["message"] = "Juego iniciado. Tu turno."
    return jsonify(game_state)

# Movimiento del jugador
@app.route('/move')
def player_move():
    action = request.args.get("action")
    
    # Lógica básica para la IA en respuesta a la acción del jugador
    if action == "apuesta":
        ai_action = random.choice(["igualo", "paso"])
    elif action == "pasa":
        ai_action = "pasa"
    elif action == "envite":
        ai_action = random.choice(["veo", "no veo"])
    elif action == "órdago":
        ai_action = random.choice(["acepto", "no acepto"])
    else:
        ai_action = "pasa"
    
    game_state["message"] = f"Tú elegiste {action}. La IA responde con {ai_action}."
    return jsonify(game_state)

if __name__ == '__main__':
    app.run(debug=True)
