import random
import numpy as np
from flask import Flask, jsonify, request

app = Flask(__name__)

# Parámetros de Q-learning
alpha = 0.1  # Tasa de aprendizaje
gamma = 0.9  # Factor de descuento
epsilon = 0.1  # Probabilidad de explorar nuevas acciones

# Inicialización de la tabla Q
q_table = {}

# Función para inicializar el estado
def get_state(player_hand, ai_hand, apuestas):
    return tuple(player_hand + ai_hand + [apuestas])

# Función para elegir la acción basada en la exploración/expotación
def choose_action(state):
    if random.uniform(0, 1) < epsilon:
        return random.choice(["pasa", "apuesta", "envida", "órdago"])
    else:
        return max(q_table.get(state, {}), key=q_table.get(state, {}).get, default="pasa")

# Función para actualizar la tabla Q
def update_q_table(state, action, reward, next_state):
    old_value = q_table.get(state, {}).get(action, 0)
    next_max = max(q_table.get(next_state, {}).values(), default=0)
    new_value = old_value + alpha * (reward + gamma * next_max - old_value)
    if state not in q_table:
        q_table[state] = {}
    q_table[state][action] = new_value

# Función de recompensa básica
def get_reward(result):
    if result == "win":
        return 10
    elif result == "lose":
        return -10
    else:
        return 0

# Ruta para hacer un movimiento
@app.route('/move')
def player_move():
    action = request.args.get("action")
    player_hand = deal_cards()
    ai_hand = deal_cards()
    apuestas = 0  # Ejemplo de estado inicial

    state = get_state(player_hand, ai_hand, apuestas)
    ai_action = choose_action(state)

    # Ejemplo de resultado aleatorio
    result = random.choice(["win", "lose", "draw"])
    reward = get_reward(result)

    next_state = get_state(player_hand, ai_hand, apuestas + 1)
    update_q_table(state, ai_action, reward, next_state)

    response = {
        "message": f"Tú elegiste {action}. La IA respondió con {ai_action}. Resultado: {result}",
        "player_hand": player_hand,
        "ai_hand": ai_hand
    }
    return jsonify(response)

def deal_cards():
    return [random.choice(["Oros", "Copas", "Espadas", "Bastos"]) for _ in range(4)]

if __name__ == '__main__':
    app.run(debug=True)
